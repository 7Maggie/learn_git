import collections
import numpy as np
import random

class ReplayBuffer(object):
    def __init__(self, input_shape, num_actions, BUFFER_CAPACITY = 3000):
        self.buffer = collections.deque()
        self.BUFFER_CAPACITY = BUFFER_CAPACITY
        self.input_shape = input_shape
        self.num_actions = num_actions

    def reset(self):
        self.buffer = collections.deque()

    def add_to_buffer(self, s, a, r, s_, is_terminal):
        transition = np.hstack([s.flatten(),[a,r],s_.flatten(),[is_terminal]])
        self.buffer.append(transition)
        if len(self.buffer) > self.BUFFER_CAPACITY:
            self.buffer.popleft()

    def sample_minibatch(self, minibatch_length):
        sample_experience = collections.deque()
        for i in range(minibatch_length):
            if len(self.buffer) == 1:
                random_int = 0
            else:
                random_int = np.random.randint(0, len(self.buffer)-1)
            sample_experience.append(self.buffer[random_int])
        return np.array(sample_experience)

#----------------------------------------------------------------------------------------------------------------------
class DeepQNetworkAgent(object):
    """ Represents a Snake agent powered by DQN with experience replay. """

    def __init__(self, model, fixed_model, num_last_frames=4, BUFFER_CAPACITY = 3000):

        assert model.input_shape[1] == num_last_frames, 'Model input shape should be (num_frames, grid_size, grid_size)'
        assert len(model.output_shape) == 2, 'Model output shape should be (num_samples, num_actions)'

        self.model = model
        self.fixed_model = fixed_model
        self.num_last_frames = num_last_frames
        self.replay_buffer = ReplayBuffer(model.input_shape[-3:], model.output_shape[-1], BUFFER_CAPACITY)
        self.discount_factor = 0.9
        self.frames = None

    def begin_episode(self):
        """ Reset the agent for a new episode. """
        self.frames = None

    def get_last_frames(self, observation):
        """
        Get the pixels of the last `num_last_frames` observations, the current frame being the last.
        
        Args:
            observation: observation at the current timestep. 

        Returns:
            Observations for the last `num_last_frames` frames.
        """
        frame = observation
        if self.frames is None:
            self.frames = collections.deque([frame] * self.num_last_frames)
        else:
            self.frames.append(frame)
            self.frames.popleft()
        return np.expand_dims(self.frames, 0)

    def update_Q_Network(self, minibatch_length):
        """ Sample a batch from experience replay. """

        sample_experience = self.replay_buffer.sample_minibatch(minibatch_length)
        input_dim = np.prod(self.model.input_shape[-3:])

        # Extract [S, a, r, S', end] from experience.
        states = sample_experience[:, :input_dim]
        actions = sample_experience[:, input_dim]
        rewards = sample_experience[:, input_dim + 1]
        next_states = sample_experience[:, input_dim + 2:2 * input_dim + 2]
        terminals = sample_experience[:, 2 * input_dim + 2]

        states = states.reshape((minibatch_length,)+self.model.input_shape[-3:])
        next_states = next_states.reshape((minibatch_length,)+self.model.input_shape[-3:])
        y_s = self.fixed_model.predict(states)
        y_s_ = self.fixed_model.predict(next_states)

        q_target = y_s.copy()
        q_target[np.arange(minibatch_length), actions] = rewards + self.discount_factor * (1 - terminals) * np.max(y_s_, axis=1)
        v1 = self.model.get_weights()
        self.model.set_weights(v1)
        loss = float(self.model.train_on_batch(states, q_target))

        return loss


    def train(self, env, num_episodes=1000, minibatch_length=50, discount_factor=0.9, checkpoint_freq=None,
              exploration_range=(1.0, 0.1), exploration_phase_size=0.5):

        # Calculate the constant exploration decay speed for each episode.
        max_exploration_rate, min_exploration_rate = exploration_range
        exploration_decay = ((max_exploration_rate - min_exploration_rate) / (num_episodes * exploration_phase_size))
        exploration_rate = max_exploration_rate

        for episode in range(num_episodes):
            # Reset the environment for the new episode.
            timestep = env.new_episode()
            self.begin_episode()
            game_over = False
            loss = 0.0

            # Observe the initial state.
            state = self.get_last_frames(timestep.observation)

            while not game_over:
                if np.random.random() < exploration_rate:
                    # Explore: take a random action.
                    action = np.random.randint(env.num_actions)
                else:
                    # Exploit: take the best known action for this state.
                    q = self.model.predict(state)
                    action = np.argmax(q[0])

                # Act on the environment.
                env.choose_action(action)
                timestep = env.timestep()

                # Remember a new piece of experience.
                reward = timestep.reward
                next_state = self.get_last_frames(timestep.observation)
                game_over = timestep.is_episode_end
                transition = [state, action, reward, next_state, game_over]
                self.replay_buffer.add_to_buffer(*transition)
                state = next_state

                loss += self.update_Q_Network(minibatch_length)

            if checkpoint_freq and (episode % checkpoint_freq) == 0:
                v1 = self.model.get_weights()
                self.fixed_model.set_weights(v1)

            if exploration_rate > min_exploration_rate:
                exploration_rate -= exploration_decay

            summary = 'Episode {:5d}/{:5d} | Loss {:8.4f} | Exploration {:.2f} | ' + \
                      'Fruits {:2d} | Timesteps {:4d} | Total Reward {:4d}'
            print(summary.format(
                episode + 1, num_episodes, loss, exploration_rate,
                env.stats.fruits_eaten, env.stats.timesteps_survived, env.stats.sum_episode_rewards,
            ))

        self.model.save('dqn-final.model')

    def act(self, observation, reward):
        state = self.get_last_frames(observation)
        q = self.model.predict(state)[0]
        return np.argmax(q)
