import matplotlib.pyplot as plt
from gameplay.environment import Environment
from keras.models import Sequential
from keras.layers import *
from keras.optimizers import *
import json
import csv
import time
import collections
import numpy as np
import random


class ReplayBuffer(object):
    def __init__(self, num_actions, BUFFER_CAPACITY):
        self.buffer = collections.deque()
        self.BUFFER_CAPACITY = BUFFER_CAPACITY
        self.num_actions = num_actions

    def add_to_buffer(self, s, a, r, s_, is_terminal):
        transition = np.hstack([s.flatten(),[a,r],s_.flatten(),1 * np.array(is_terminal).flatten()])
        self.buffer.append(transition)
        # if len(self.buffer) > self.BUFFER_CAPACITY:
        #     self.buffer.popleft()

    def sample_minibatch(self, minibatch_length):
        sample_experience = np.array(random.sample(self.buffer, minibatch_length))
        return sample_experience

class DQNAgent(object):

    def __init__(self, model, fixed_model, BUFFER_CAPACITY = 30000):
        self.model = model
        self.fixed_model = fixed_model
        self.replay_buffer = ReplayBuffer(model.output_shape[-1], BUFFER_CAPACITY)
        self.discount_factor = 0.95
        self.epsilon_max = 1
        self.epsilon_min = 0.1
        self.rewards_lst = []
        self.history_s = None

    def begin_episode(self):
        pass
    def end_episode(self):
        pass

    def update_Q_Network(self, minibatch_length):

        enough = True
        if len(self.replay_buffer.buffer) <= 100:
            enough = False

        minibatch_length = min(len(self.replay_buffer.buffer), minibatch_length)
        sample_experience = self.replay_buffer.sample_minibatch(minibatch_length)
        split_index = np.prod(self.model.input_shape[-3:])

        states = sample_experience[:, :split_index].reshape((minibatch_length,)+self.model.input_shape[-3:])
        actions = sample_experience[:, split_index].astype(int)
        rewards = sample_experience[:, split_index + 1]
        next_states = sample_experience[:, split_index + 2 : 2 * split_index + 2].reshape((minibatch_length,)+self.model.input_shape[-3:])
        terminals = sample_experience[:, 2 * split_index + 2]

        y_s = self.model.predict(states)
        fix_y_s_ = self.fixed_model.predict(next_states)
        next_actions = np.argmax(self.model.predict(next_states),axis=1)
        
        q_target = y_s.copy()
        q_target[np.arange(minibatch_length), actions] = rewards + self.discount_factor * (1 - terminals) * fix_y_s_[np.arange(minibatch_length),next_actions]

        return states, q_target, enough

    def transform_state(self,observation):
        if self.history_s is None:
            self.history_s = collections.deque()
            for i in range(4):
                self.history_s.append(observation)
        else:
            self.history_s.append(observation)
            self.history_s.popleft()
        return np.array(self.history_s)[np.newaxis, :, :, :]

    def train(self, env, N_episodes=3000, minibatch_length=50):
        target_replace_iter = N_episodes // 10
        epsilon = self.epsilon_max
        epsilon_decay = (self.epsilon_max - self.epsilon_min) / (N_episodes * 0.5)

        for episode in range(N_episodes):
            timestep = env.new_episode()
            is_terminal= False
            loss = 0.0
            total_reward = 0.0
            self.history_s = None
            # get initial state.
            state = self.transform_state(timestep.observation)
            while not is_terminal:
                if np.random.random() < epsilon:
                    action = np.random.randint(env.num_actions)
                else:
                    qsa = self.model.predict(state)[0]
                    action = np.argmax(qsa)
                env.choose_action(action)
                timestep = env.timestep()
                reward = timestep.reward
                total_reward += reward
                next_state = self.transform_state(timestep.observation)
                is_terminal = timestep.is_episode_end
                transition = [state, action, reward, next_state, is_terminal]
                self.replay_buffer.add_to_buffer(*transition)
                state = next_state

                x,y,enough = self.update_Q_Network(minibatch_length)
                if enough == True:
                    loss += float(self.model.train_on_batch(x,y))
                else:
                    continue

            self.rewards_lst.append(total_reward)

            if target_replace_iter and (episode % target_replace_iter) == 0:
                v1 = self.model.get_weights()
                self.fixed_model.set_weights(v1)

            if epsilon > self.epsilon_min:
                epsilon -= epsilon_decay

            summary = 'Episode {:5d}/{:5d} | Loss {:8.4f} | Exploration {:.2f} | ' + \
                      'Fruits {:2d} | Timesteps {:4d} | Total Reward {:8.1f}'
            print(summary.format(
                episode + 1, N_episodes, loss, epsilon,
                env.stats.fruits_eaten, env.stats.timesteps_survived, env.stats.sum_episode_rewards,
            ))
        self.model.save('dqn-final.model')

    def act(self, observation, reward):
        state = self.transform_state(observation)
        qsa = self.model.predict(state)[0]
        return np.argmax(qsa)

def built_dqn(env):
    model = Sequential([
        Conv2D(16, kernel_size=(3, 3), strides=(1, 1), data_format='channels_first',
               input_shape=(4,) + env.observation_shape),
        Activation('relu'),
        Conv2D(32, kernel_size=(3, 3), strides=(1, 1), data_format='channels_first'),
        Activation('relu'),
        Flatten(),
        Dense(256),
        Activation('relu'),
        Dense(env.num_actions)
    ])
    model.compile(RMSprop(), 'MSE')
    return model


def record_csv(rewards_lst):
    timestamp = time.strftime('%Y%m%d-%H%M%S')
    with open("train_rewards-{}.csv".format(timestamp), "a", newline='', encoding='utf-8') as file:
        writer = csv.writer(file, delimiter=',')
        writer.writerow(rewards_lst)
        
def plot_rewards(r):
    cum_r = np.cumsum(r)
    avg_rewards = []
    for i in range(1, len(r)):
        if i % 20 == 0:
            t1 = np.mean(r[i - 20:i])
            avg_rewards.append(t1)
    plt.figure(1)
    plt.plot(cum_r)
    plt.xlabel('Episodes Played')
    plt.ylabel('Cumulative Rewards')
    plt.title('Cumulative Rewards \n Earned By Agent')
    plt.figure(2)
    plt.plot(avg_rewards)
    plt.xlabel('Episodes Played')
    plt.ylabel('Average Return')
    plt.title('Learning Curve \n Performance Averaged Over Every 20 Episodes')
    plt.show()

def main():
    with open('10x10-blank.json') as cfg:
        env_config = json.load(cfg)
    env = Environment(config=env_config, verbose=1)

    model = built_dqn(env)
    fixed_model = built_dqn(env)
    agent = DQNAgent(model = model,fixed_model = fixed_model,BUFFER_CAPACITY=30000)
    agent.train(env,minibatch_length = 64,N_episodes = 10000)

    r = np.array(agent.rewards_lst)
    record_csv(r)
    plot_rewards(r)

if __name__ == '__main__':
    main()
