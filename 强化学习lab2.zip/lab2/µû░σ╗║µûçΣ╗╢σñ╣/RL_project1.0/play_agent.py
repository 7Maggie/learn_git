from keras.models import load_model
import matplotlib.pyplot as plt
import csv
import time
import json
import numpy as np
import argparse
from gameplay.environment import Environment
from gui import PyGameGUI
from dqn import DQNAgent
from random_agent import RandomAgent


def choose_agent(agent_type, model, fixed_model):
    if agent_type == 'dqn':
        return DQNAgent(model=model, fixed_model=fixed_model)
    elif agent_type == 'random':
        return RandomAgent()

def get_text_output(env,agent,N_episodes=10):
    fruit_stats = []
    rewards_lst = []
    print('Playing:')
    for episode in range(N_episodes):
        timestep = env.new_episode()
        is_terminal = False
        total_reward = 0
        while not is_terminal:
            action = agent.act(timestep.observation, timestep.reward)
            env.choose_action(action)
            timestep = env.timestep()
            total_reward += timestep.reward
            is_terminal = timestep.is_episode_end
        fruit_stats.append(env.stats.fruits_eaten)
        summary = 'Episode {:3d} / {:3d} | Timesteps {:4d} | Fruits {:2d} | Total_reward {:2d}'
        print(summary.format(episode + 1, N_episodes, env.stats.timesteps_survived, env.stats.fruits_eaten,env.stats.sum_episode_rewards))
        rewards_lst.append(total_reward)
    print('Average Fruits eaten {:.1f}'.format(np.mean(fruit_stats)))
    record_csv(rewards_lst)
    plot_rewards(rewards_lst)
    return rewards_lst

def get_gui_output(env,agent,N_episodes=10):
    gui = PyGameGUI()
    gui.load_environment(env)
    gui.load_agent(agent)
    gui.run(num_episodes = N_episodes)

def record_csv(rewards_lst):
    timestamp = time.strftime('%Y%m%d-%H%M%S')
    with open("play_rewards-{}.csv".format(timestamp), "a", newline='', encoding='utf-8') as file:
        writer = csv.writer(file, delimiter=',')
        writer.writerow(rewards_lst)

def plot_rewards(rewards_lst):
    r = np.array(rewards_lst)
    cum_r = np.cumsum(r)
    avg_rewards = []
    for i in range(1, len(r)):
        if i % 20 == 0:
            t1 = np.mean(r[i - 20:i])
            avg_rewards.append(t1)
    plt.figure(1)
    plt.plot(cum_r)
    plt.xlabel('Episodes Played')
    plt.ylabel('Cumulative Rewards')
    plt.title('Cumulative Rewards \n Earned By Agent')
    plt.figure(2)
    plt.plot(avg_rewards)
    plt.xlabel('Episodes Played')
    plt.ylabel('Average Return')
    plt.title('Learning Curve \n Performance Averaged Over Every 20 Episodes')
    plt.show()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--agent',
                        required=True,
                        choices = ['random','dqn'],
                        type = str,
                        help='the agent')
    parser.add_argument('--output',
                        type = str,
                        choices=['text', 'gui'],
                        default='gui',
                        help='output mode (text or GUI)')
    parser.add_argument('--model',
                        type=str,
                        default='dqn-final.model',
                        help='File containing the trained model')
    parser.add_argument('--level',
                        default='10x10-blank.json',
                        type = str,
                        help='JSON file containing a level definition')
    parser.add_argument('--N_episodes',
                        type=int,
                        default=10,
                        help='The number of episodes to play')

    opt = parser.parse_args()
    with open(opt.level) as cfg:
        env_config = json.load(cfg)
    env = Environment(config=env_config, verbose=1)
    model = load_model(opt.model)
    agent = choose_agent(opt.agent, model, model)

    if opt.output == 'text':
        get_text_output(env, agent, N_episodes = opt.N_episodes)
    else:
        get_gui_output(env,agent,N_episodes=opt.N_episodes)

if __name__ == '__main__':
    main()