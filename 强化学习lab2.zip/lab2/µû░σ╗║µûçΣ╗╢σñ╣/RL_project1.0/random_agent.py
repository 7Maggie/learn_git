import random
from gameplay.entities import ALL_SNAKE_ACTIONS

class RandomAgent(object):
    def __init__(self):
        pass
    def begin_episode(self):
        pass
    def act(self, observation, reward):
        return random.choice(ALL_SNAKE_ACTIONS)
    def end_episode(self):
        pass